#include <gtk/gtk.h>

typedef struct
{
char nom[30];
char prenom[30];
char sexe[30];
char cin[30];
}medecin ;
void affichpmedecin(GtkWidget *liste);
