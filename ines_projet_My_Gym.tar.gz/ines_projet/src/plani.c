#include <stdio.h>
#include <string.h>
#include "plani.h"
#include <gtk/gtk.h>


void affichplani(GtkWidget *liste)
{
enum
{  NUMD,
   NJOUR,
   JOUR,
   MOIS,
   ANNEE,
   HORAIRE,
   COLUMNS
};
     GtkCellRenderer *renderer;
     GtkTreeViewColumn *column;
     GtkTreeIter  iter;
     GtkListStore *store;


     char numd[20];
     char njour[30];
     char jour[20];
     char mois[20];
     char annee[20];
     char horaire[40];
     store=NULL;

     FILE *f;

     //store=gtk_tree_view_get_model(liste);
     if(store==NULL)
     {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("numd", renderer, "text", NUMD, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("njour", renderer, "text", NJOUR, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text", JOUR, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);



        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text", MOIS, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",ANNEE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("horaire", renderer, "text", HORAIRE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);}

        
        store=gtk_list_store_new(6, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
        f = fopen("/home/bouguerra/Bureau/ines_projet/src/planning.txt","r");
        if(f!=NULL)
        {
              return;
         }
         else
         { f = fopen("/home/bouguerra/Bureau/ines_projet/src/planning.txt", "a+");
                    while(fscanf(f, "%s %s %s %s %s %s\n",numd,njour,jour,mois,annee,horaire)!=EOF)
            {
                 gtk_list_store_append (store, &iter);
                 gtk_list_store_set(store,&iter, NUMD, numd, NJOUR, njour, JOUR, jour, MOIS, mois, ANNEE, annee, HORAIRE, horaire, -1);
              
              fclose(f);
}
         gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
         g_object_unref (store);
         }
      
}
