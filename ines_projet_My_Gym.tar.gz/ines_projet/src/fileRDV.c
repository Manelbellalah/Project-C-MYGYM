#include <stdio.h>
#include <string.h>
#include "fileRDV.h"
#include <gtk/gtk.h>
enum
{  NUMERO,
   JOURNEE,
   HEURE,
   RDV,
   COLUMNS
};
void ajoRDV(rdvadh r)
{
FILE *f;
f=fopen("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s\n",r.numero,r.journee,r.heure,r.rdv);
fclose(f);
}
}
void affichRDV(GtkWidget *liste)
{
     GtkCellRenderer *renderer;
     GtkTreeViewColumn *column;
     GtkTreeIter  iter;
     GtkListStore *store;


     char numero[30];
     char journee[30];
     char heure[30];
     char rdv[30];
     store=NULL;

     FILE *f;

      //store=gtk_tree_view_get_model(liste);
     if(store==NULL)
     {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("numero", renderer, "text", NUMERO, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("journee", renderer, "text", JOURNEE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("heure", renderer, "text", HEURE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);



        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("rdv", renderer, "text", RDV, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
        f = fopen("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt","r");
        if(f==NULL)
        {
              return;
         }
         else
         { f = fopen("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt", "a+");
                    while(fscanf(f, "%s %s %s %s\n",numero,journee,heure,rdv)!=EOF)
            {
                 gtk_list_store_append (store, &iter);
                 gtk_list_store_set(store,&iter, NUMERO, numero, JOURNEE, journee, HEURE,heure, RDV,rdv, -1);
              }
              fclose(f);
         gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
         g_object_unref (store);
         }
      }
}


/*void modifRDV(char numero1[],char journee1[],char heure1[],char rdv1[])

{
FILE *f;
FILE *f1;
rdvadh r;
int test=-1;
f=fopen("mes_RDV.txt","r");
f1=fopen("fich.txt","a+");
while (fscanf(f,"%s %s %s %s",r.numero,r.journee,r.heure,r.rdv)!=EOF)
{if (r.numero!=numero1)
fprintf(f1,"%s %s %s %s\n",r.numero,r.journee,r.heure,r.rdv);
else 
fprintf(f1,"%s %s %s %s\n",numero1,journee1,heure1,rdv1);

}
fclose(f);
fclose(f1);
rename("fich.txt","mes_RDV.txt");

}*/
