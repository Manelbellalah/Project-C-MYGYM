#include <gtk/gtk.h>
void supprimerRDV(char numRDV1[]);
