#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "supRDV.h"

void supprimerRDV(char numRDV1[])
{

char jour[20];
char heure[20];
char rdv[20];
char numero [30];
FILE* f;
FILE* f1;
f=fopen("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt","r");
f1=fopen("/home/bouguerra/Bureau/ines_projet/src/filesup.tmp","a+");
while (fscanf(f,"%s %s %s %s\n",numero,jour,heure,rdv)!= EOF)
{if (strcmp(numero,numRDV1)!=0)
     {
           fprintf(f1,"%s %s %s %s\n",numero,jour,heure,rdv);
      }
}
fclose(f);
fclose(f1);
remove("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt");
rename("/home/bouguerra/Bureau/ines_projet/src/filesup.tmp","/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt");
}
