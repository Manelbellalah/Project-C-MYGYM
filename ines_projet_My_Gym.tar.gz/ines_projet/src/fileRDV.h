#include <gtk/gtk.h>

typedef struct
{
char numero[30];
char journee[30];
char heure[30];
char rdv[30];
}rdvadh ;
void ajoRDV(rdvadh r);
void affichRDV(GtkWidget *liste);

