#include <gtk/gtk.h>

typedef struct
{
char nom[50];
char prenom[50];
char sexe[50];
char cin[50];
char numero[50];
char spetialite[50];
}coach ;
void affichco(GtkWidget *liste);
