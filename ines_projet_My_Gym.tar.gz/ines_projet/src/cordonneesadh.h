#include <gtk/gtk.h>

typedef struct
{
char nom[20];
char prenom[20];
char cin[8];
char profession[20];
char objectifs[50];
char adresse[30];
char telephone[30];
char mail[30];
char poids[30];
char typesport[50];
}coordonneesadh;
void ajouter_coordonnees_adherent(coordonneesadh adh);
void afficher_coordonnees_adherent(coordonneesadh adh);
void modifprofiladh(coordonneesadh adh);
