#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verrif.h"
#include "fileRDV.h"
#include "cordonneesadh.h"
#include "supRDV.h"
#include "affichm.h"
#include "affichc.h"
#include "plani.h"
#include "modifrdv.h"
#include <string.h>

void on_loginadh_clicked  (GtkWidget *widget, gpointer user_data)
{
int v;
GtkWidget *login;
GtkWidget *password1;
GtkWidget *role1;
GtkWidget *adherent;
GtkWidget *window1;
adherent=create_adherent();

char username[20];
char password[20];
int role ;
login=lookup_widget(widget ,"entry1");
password1=lookup_widget(widget ,"entry2");
//role=lookup_widget(widget,"role")
strcpy(username,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(password1)));
v = verrif (username , password);
if (v==1){
window1=lookup_widget(widget,"window1");
gtk_widget_show(adherent);
gtk_widget_hide(window1);}
}


void on_acceuiladh_clicked (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *adherent, *acceuil;
acceuil=create_acceuil();
adherent=lookup_widget(objet_graphique,"adherent");
gtk_widget_show(acceuil);
gtk_widget_hide(adherent);
}


void on_quitterespaceadh_clicked (GtkWidget *widget,gpointer user_data)
{
gtk_main_quit();
}


void on_profiladh_clicked (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *acceuil, *profil;
profil=create_profil();
acceuil=lookup_widget(objet_graphique,"acceuil");
gtk_widget_show(profil);
gtk_widget_hide(acceuil);
}
void on_demandezRDVadh_clicked (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *acceuil, *demandezRDV;
demandezRDV=create_demandezRDV();
acceuil=lookup_widget(objet_graphique,"acceuil");
gtk_widget_show(demandezRDV);
gtk_widget_hide(acceuil);
}

void on_buttonajoRDV_clicked  (GtkWidget *objet, gpointer user_data)
{
rdvadh r;
GtkWidget *input1RDV,*input2RDV, *input3RDV,*input4RDV;
GtkWidget *demandezRDV;
demandezRDV=lookup_widget(objet,"demandezRDV");

input1RDV=lookup_widget(objet,"entryjour");
input2RDV=lookup_widget(objet,"entryheure");
input3RDV=lookup_widget(objet,"entryRDV");
input4RDV=lookup_widget(objet,"entrynumRDV");
strcpy(r.journee,gtk_entry_get_text(GTK_ENTRY(input1RDV)));
strcpy(r.heure,gtk_entry_get_text(GTK_ENTRY(input2RDV)));
strcpy(r.rdv,gtk_entry_get_text(GTK_ENTRY(input3RDV)));
strcpy(r.numero,gtk_entry_get_text(GTK_ENTRY(input4RDV)));
ajoRDV(r);
}


void on_buttonafficherRDV_clicked (GtkWidget *objet, gpointer user_data)
{ 
GtkWidget *demandezRDV;
GtkWidget *listeRDV;
GtkWidget *treeview1;

demandezRDV=lookup_widget(objet,"demandezRDV");
gtk_widget_destroy(demandezRDV);

listeRDV=lookup_widget(objet,"listeRDV");
listeRDV=create_listeRDV();
gtk_widget_show(listeRDV);     
treeview1=lookup_widget(listeRDV,"treeview1");
affichRDV(treeview1);
}




void on_buttonretourRDVacc_clicked (GtkWidget *objet, gpointer user_data)
{
GtkWidget *demandezRDV, *acceuil;
demandezRDV=lookup_widget(objet,"demandezRDV");

gtk_widget_destroy(demandezRDV);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}

void
on_retourlisteRDVdemandezRDV_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *listeRDV, *demandezRDV;
listeRDV=lookup_widget(objet,"listeRDV");

gtk_widget_destroy(listeRDV);
demandezRDV=create_demandezRDV();
gtk_widget_show(demandezRDV);
}

void
on_buttonretourprofilacc_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *profil, *acceuil;
profil=lookup_widget(objet,"profil");

gtk_widget_destroy(profil);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}


void
on_buttonajoprofil_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
coordonneesadh adh;
GtkWidget *comboboxtypesport;
GtkWidget *poids;
GtkWidget *input1adh,*input2adh, *input3adh,*input4adh,*input5adh,*input6adh,*input7adh, *input8adh, *input9adh;
GtkWidget *profil;
profil=lookup_widget(objet,"profil");

input1adh=lookup_widget(objet,"entrynom");
input2adh=lookup_widget(objet,"entryprenom");
input3adh=lookup_widget(objet,"entrycin");
input4adh=lookup_widget(objet,"entryprofession");
input5adh=lookup_widget(objet,"entryobjectifs");
input6adh=lookup_widget(objet,"entryadresse");
input7adh=lookup_widget(objet,"entrytlf");
input8adh=lookup_widget(objet,"entrymail");
comboboxtypesport=lookup_widget(objet, "comboboxtypesport");
input9adh=lookup_widget(objet, "spinbutton4");

//adh.poids=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (input9adh));
strcpy(adh.poids,gtk_entry_get_text(GTK_ENTRY(input9adh)));
strcpy(adh.nom,gtk_entry_get_text(GTK_ENTRY(input1adh)));
strcpy(adh.prenom,gtk_entry_get_text(GTK_ENTRY(input2adh)));
strcpy(adh.cin,gtk_entry_get_text(GTK_ENTRY(input3adh)));
strcpy(adh.profession,gtk_entry_get_text(GTK_ENTRY(input4adh)));
strcpy(adh.objectifs,gtk_entry_get_text(GTK_ENTRY(input5adh)));
strcpy(adh.adresse,gtk_entry_get_text(GTK_ENTRY(input6adh)));
strcpy(adh.telephone,gtk_entry_get_text(GTK_ENTRY(input7adh)));
strcpy(adh.mail,gtk_entry_get_text(GTK_ENTRY(input8adh)));
//strcpy(adh.poids,gtk_entry_get_text(GTK_ENTRY(input9adh)));
strcpy(adh.typesport,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtypesport)));

   

ajouter_coordonnees_adherent(adh);
}


void
on_buttonmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1adh,*input2adh, *input3adh,*input4adh,*input5adh,*input6adh,*input7adh,*input8adh,*comboboxtypesport;
coordonneesadh adh;          
input1adh=lookup_widget(objet,"entrynom");
input2adh=lookup_widget(objet,"entryprenom");
input3adh=lookup_widget(objet,"entrycin");
input4adh=lookup_widget(objet,"entryprofession");
input5adh=lookup_widget(objet,"entryobjectifs");
input6adh=lookup_widget(objet,"entryadresse");
input7adh=lookup_widget(objet,"entrytlf");
input8adh=lookup_widget(objet,"entrymail");
//input9adh=lookup_widget(objet,"spinbutton4");
comboboxtypesport=lookup_widget(objet,"comboboxtypesport");
//input9adh=lookup_widget(objet,"spinbutton4");
strcpy(adh.nom,gtk_entry_get_text(GTK_ENTRY(input1adh)));
strcpy(adh.prenom,gtk_entry_get_text(GTK_ENTRY(input2adh)));
strcpy(adh.cin,gtk_entry_get_text(GTK_ENTRY(input3adh)));
strcpy(adh.profession,gtk_entry_get_text(GTK_ENTRY(input4adh)));
strcpy(adh.objectifs,gtk_entry_get_text(GTK_ENTRY(input5adh)));
strcpy(adh.adresse,gtk_entry_get_text(GTK_ENTRY(input6adh)));
strcpy(adh.telephone,gtk_entry_get_text(GTK_ENTRY(input7adh)));
strcpy(adh.mail,gtk_entry_get_text(GTK_ENTRY(input8adh)));
//strcpy(adh.poids,gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9adh)));
strcpy(adh.typesport,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtypesport)));
modifprofiladh(adh);
}


void
on_buttonquitacc_clicked               (GtkWidget       *widget,                                      gpointer         user_data)
{
gtk_main_quit();
}


/*void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
//GtkWidget *combobox1;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *combobox3;
GtkWidget *combobox2;
char bloc;
char Bloc[50];
char nom_salle[100][100];
Date dt_resr;
int i,n,hr_resr;
char stringNum[20];
int num=100;

// associé les objets avec des variables
//combobox1=lookup_widget(objet_graphique, "combobox1");
jour=lookup_widget(objet_graphique, "spinbutton1");
mois=lookup_widget(objet_graphique, "spinbutton2");
annee=lookup_widget(objet_graphique, "spinbutton3");

combobox3=lookup_widget(objet_graphique, "combobox3");
combobox2=lookup_widget(objet_graphique, "combobox2");


récuperer les valeurs 
dt_resr.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
dt_resr.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
dt_resr.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

if(strcmp("9h ==>10h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0) 
hr_resr=1;
else if(strcmp("11h ==>12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0) 
hr_resr=2;
     else if(strcmp("14h ==>15h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0) 
hr_resr=3;
          else 
hr_resr=4;

strcpy(Bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
bloc=Bloc[0];

 n=tableau_salle_disponible(nom_salle, bloc, dt_resr, hr_resr);
for(i=0;i<n;i++)
{
  gtk_combo_box_append_text (GTK_COMBO_BOX (combobox1), _(nom_salle[i]));

}
}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox1;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *combobox3;
GtkWidget *combobox2;
GtkWidget *label11;
char Bloc[20];
ReservationSalle s;

combobox1=lookup_widget(objet_graphique, "combobox1");
label11=lookup_widget(objet_graphique, "label11");
jour=lookup_widget(objet_graphique, "spinbutton1");
mois=lookup_widget(objet_graphique, "spinbutton2");
annee=lookup_widget(objet_graphique, "spinbutton3");

label11=lookup_widget(objet_graphique, "label11");

combobox3=lookup_widget(objet_graphique, "combobox3");
combobox2=lookup_widget(objet_graphique, "combobox2");
s.dt_res.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_res.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_res.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

if(strcmp("9h ==>10h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0) 
s.hr_resr=1;
else if(strcmp("11h ==>12h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0) 
s.hr_resr=2;
     else if(strcmp("14h ==>15h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)))==0) 
s.hr_resr=3;
          else 
s.hr_resr=4;

strcpy(Bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
s.bloc=Bloc[0];


strcpy(s.num,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

reserver_salle( s);


gtk_label_set_text(GTK_LABEL(label11),"votre RDV a été fixé avec succés .");
}


void
on_buttunRDVfixe_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3, *acceuil;
acceuil=lookup_widget(objet,"acceuil");

gtk_widget_destroy(acceuil);
window3=create_window3();
gtk_widget_show(window3);
}*/


void
on_buttonsupprimeradh_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *listeRDV, *supressionadh;
listeRDV=lookup_widget(objet,"listeRDV");

gtk_widget_destroy(listeRDV);
supressionadh=create_supressionadh();
gtk_widget_show(supressionadh);
}


void
on_buttonvalidersup_clicked            (GtkWidget       *widget,
                                        gpointer         user_data)
{
char numRDV1[30];

	GtkWidget *input1;
	GtkWidget *supprimer;

	supprimer=lookup_widget(widget,"supprimer");

	input1=lookup_widget(widget,"entryrecherche");

	strcpy(numRDV1,gtk_entry_get_text(GTK_ENTRY(input1)));
	
	supprimerRDV(numRDV1);
}


void
on_annulersup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *demandezRDV, *supressionadh;
supressionadh=lookup_widget(objet,"supressionadh");

gtk_widget_destroy(supressionadh);
demandezRDV=create_demandezRDV();
gtk_widget_show(demandezRDV);
}


void
on_buttonretoursconsulterstaf_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *consulterstaff, *listeprofilcoachstaf;
consulterstaff=lookup_widget(objet,"consulterstaff");

gtk_widget_destroy(consulterstaff);
listeprofilcoachstaf=create_listeprofilcoachstaf();
gtk_widget_show(listeprofilcoachstaf);
}


/*void
on_buttonretourRDV2_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3, *acceuil;
window3=lookup_widget(objet,"window3");

gtk_widget_destroy(window3);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}




void
on_afficherRDV2_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *listeRDV;
GtkWidget *treeview1;

window3=lookup_widget(objet,"window3");
gtk_widget_destroy(window3);

listeRDV=lookup_widget(objet,"listeRDV");
listeRDV=create_listeRDV();
gtk_widget_show(listeRDV);     
treeview1=lookup_widget(listeRDV,"treeview1");
affichRDV(treeview1);*/



void
on_buttonretourlscoaacc_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *consultercoach, *listeprofilcoachstaf;
consultercoach=lookup_widget(objet,"consultercoach");

gtk_widget_destroy(consultercoach);
listeprofilcoachstaf=create_listeprofilcoachstaf();
gtk_widget_show(listeprofilcoachstaf);
}



void
on_buttonretourcacc_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *acceuil, *listeprofilcoachstaf;
listeprofilcoachstaf=lookup_widget(objet,"listeprofilcoachstaf");

gtk_widget_destroy(listeprofilcoachstaf);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}


void
on_buttoncoach_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *consultercoach, *listeprofilcoachstaf;
GtkWidget *treeview3;
listeprofilcoachstaf=lookup_widget(objet,"listeprofilcoachstaf");

gtk_widget_destroy(listeprofilcoachstaf);
consultercoach=create_consultercoach();
gtk_widget_show(consultercoach);
treeview3=lookup_widget(consultercoach,"treeview3");
affichco(treeview3);
}


void
on_buttonstaff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *consulterstaff, *listeprofilcoachstaf;
GtkWidget *treeview2;
listeprofilcoachstaf=lookup_widget(objet,"listeprofilcoachstaf");

gtk_widget_destroy(listeprofilcoachstaf);
consulterstaff=create_consulterstaff();
gtk_widget_show(consulterstaff);
treeview2=lookup_widget(consulterstaff,"treeview2");
affichpmedecin(treeview2);
}


void
on_buttonstaffmedical_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *acceuil, *listeprofilcoachstaf;
acceuil=lookup_widget(objet,"acceuil");

gtk_widget_destroy(acceuil);
listeprofilcoachstaf=create_listeprofilcoachstaf();
gtk_widget_show(listeprofilcoachstaf);
}


void
on_buttonretourpacc_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *consulterplani, *acceuil;
consulterplani=lookup_widget(objet,"consulterplani");

gtk_widget_destroy(consulterplani);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}


void
on_buttonplani_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *consulterplani;
GtkWidget *acceuil;
GtkWidget *treeview4;
acceuil=lookup_widget(objet,"acceuil");


consulterplani=create_consulterplani();
treeview4=lookup_widget(consulterplani,"treeview4");


gtk_widget_show(consulterplani);
gtk_widget_hide(acceuil);
affichplani(treeview4);
}



void
on_buttonaffichprofil_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{

coordonneesadh adh;
GtkWidget *output1adh,*output2adh, *output3adh,*output4adh,*output5adh,*output6adh,*output7adh, *output8adh, *output9adh,*output10adh;
output1adh=lookup_widget(objet,"entrynom");
output2adh=lookup_widget(objet,"entryprenom");
output3adh=lookup_widget(objet,"entrycin");
output4adh=lookup_widget(objet,"entryprofession");
output5adh=lookup_widget(objet,"entryobjectifs");
output6adh=lookup_widget(objet,"entryadresse");
output7adh=lookup_widget(objet,"entrytlf");
output8adh=lookup_widget(objet,"entrymail");
output9adh=lookup_widget(objet,"spinbutton4");
output10adh=lookup_widget(objet,"comboboxtypesport");


int x=1;
FILE *f;
f=fopen("pp.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s",adh.nom,adh.prenom,adh.cin,adh.profession,adh.objectifs,adh.adresse,adh.telephone,adh.mail,adh.poids,adh.typesport)!=EOF)
{
//if (x==1)

gtk_entry_set_text (GTK_ENTRY (output1adh),adh.nom);
gtk_entry_set_text (GTK_ENTRY (output2adh),adh.prenom);
gtk_entry_set_text (GTK_ENTRY (output3adh),adh.cin);
gtk_entry_set_text (GTK_ENTRY (output4adh),adh.profession);
gtk_entry_set_text (GTK_ENTRY (output5adh),adh.objectifs);
gtk_entry_set_text (GTK_ENTRY (output6adh),adh.adresse);
gtk_entry_set_text (GTK_ENTRY (output7adh),adh.telephone);
gtk_entry_set_text (GTK_ENTRY (output8adh),adh.mail);
//gtk_entry_set_text (GTK_ENTRY (output9adh), adh.poids);
//}
}
}
fclose(f);
}

/*void
on_buttonmodifRDV_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *numero1;
GtkWidget *journee1;
GtkWidget *heure1;
GtkWidget *rdv1;
rdvadh r;
journee1=lookup_widget(objet,"entryjour");
heure1=lookup_widget(objet,"entryheure");
rdv1=lookup_widget(objet,"entryRDV");
numero1=lookup_widget(objet,"entrynumRDV");

strcpy(r.numero,gtk_entry_get_text(GTK_ENTRY(numero1)));
strcpy(r.journee,gtk_entry_get_text(GTK_ENTRY(journee1)));
strcpy(r.heure,gtk_entry_get_text(GTK_ENTRY(heure1)));
strcpy(r.rdv,gtk_entry_get_text(GTK_ENTRY(rdv1)));

modifRDV(numero1,journee1,heure1,rdv1);
}*/


void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *demandezRDV, *modifiermonrdv;
demandezRDV=lookup_widget(objet,"demandezRDV");

gtk_widget_destroy(demandezRDV);
modifiermonrdv=create_modifiermonrdv();
gtk_widget_show(modifiermonrdv);
}


void
on_buttonretourrdv2rdv1_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *demandezRDV, *modifiermonrdv;
modifiermonrdv=lookup_widget(objet,"modifiermonrdv");

gtk_widget_destroy(modifiermonrdv);
demandezRDV=create_demandezRDV();
gtk_widget_show(demandezRDV);
}


void
on_buttonvaliderdv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
rdv2adh r;
GtkWidget *numero1;
GtkWidget *journee1;
GtkWidget *heure1;
GtkWidget *rdv1;
GtkWidget *modifiermonrdv;

modifiermonrdv=lookup_widget(objet,"modifiermonrdv");
journee1=lookup_widget(objet,"entryjour2");
heure1=lookup_widget(objet,"entryheure2");
rdv1=lookup_widget(objet,"entryrdv2");
numero1=lookup_widget(objet,"entrynumRDV2");

strcpy(r.numero,gtk_entry_get_text(GTK_ENTRY(numero1)));
strcpy(r.journee,gtk_entry_get_text(GTK_ENTRY(journee1)));
strcpy(r.heure,gtk_entry_get_text(GTK_ENTRY(heure1)));
strcpy(r.rdv,gtk_entry_get_text(GTK_ENTRY(rdv1)));

modifmonrdv(r);
}

