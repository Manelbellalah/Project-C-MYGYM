#include <gtk/gtk.h>

typedef struct
{
char numero[30];
char journee[30];
char heure[30];
char rdv[30];
}rdv2adh ;
void modifmonrdv(rdv2adh r);
