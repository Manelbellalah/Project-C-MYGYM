#include <gtk/gtk.h>

typedef struct
{
     char numd[20];
     char njour[30];
     char jour[20];
     char mois[20];
     char annee[20];
     char horaire[40];
}Datep ;
void affichplani(GtkWidget *liste);
