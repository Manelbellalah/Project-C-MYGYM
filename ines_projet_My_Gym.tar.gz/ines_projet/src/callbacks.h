#include <gtk/gtk.h>


void
on_loginadh_clicked                    (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_acceuiladh_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitterespaceadh_clicked            (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_profiladh_clicked                   (GtkWidget       *widget,
                                        gpointer         user_data);
void on_demandezRDVadh_clicked (GtkWidget *widget,gpointer user_data);

void
on_buttonafficherRDV_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonretourRDVacc_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonOK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourlisteRDVdemandezRDV_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretourprofilacc_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonajoprofil_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonajoRDV_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_buttonquitacc_clicked               (GtkWidget       *widget,
                                        gpointer         user_data);

/*void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttunRDVfixe_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);*/

void
on_buttonsupprimeradh_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonvalidersup_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_annulersup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretoursconsulterstaf_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

/*void
on_buttonretourRDV2_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherRDV2_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);*/

void
on_buttonretourlscoaacc_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretourcacc_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttoncoach_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonstaff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonstaffmedical_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretourpacc_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonplani_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonaffichprofil_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

/*void
on_buttonmodifRDV_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);*/

void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretourrdv2rdv1_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonvaliderdv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
