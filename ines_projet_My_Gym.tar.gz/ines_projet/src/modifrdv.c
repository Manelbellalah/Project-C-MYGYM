#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileRDV.h"
#include "modifrdv.h"



void modifmonrdv(rdv2adh r)//parametre mte3na
{
	FILE *f;
	FILE *ftemp;
	FILE *file_ptr;
	rdv2adh x;
	f=fopen("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt","r");
	ftemp=fopen("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.tmp","w");
	if (f!=NULL)
	{
    		while(fscanf(f,"%s %s %s %s\n",x.numero,x.journee,x.heure,x.rdv)!=EOF)//na9raw il fichier mte3na
    		{
      			if(strcmp(r.numero,x.numero)!=0){//ken il parametre different mil ligne na3mlou copie mak i ligne fil fichier ejdid
        			fprintf(ftemp,"%s %s %s %s\n",x.numero,x.journee,x.heure,x.rdv);}

      			else{//ken il parametre kima i ligne ili na9rawfeha nwaliw najoutiw i ligne iliejdida w na79rou le9dima mehech rajel
        			fprintf(ftemp,"%s %s %s %s\n",r.numero,r.journee,r.heure,r.rdv);//l ajout mta3 i ligne elmodifier fel fichier ijdid
         	}
	}
}
	fclose(f);
	fclose(ftemp);
	remove("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt");//nfaskhou ilfichier lasleni 
	rename("/home/bouguerra/Bureau/ines_projet/src/mes_RDV.tmp","/home/bouguerra/Bureau/ines_projet/src/mes_RDV.txt");//nranomiw il fichier ejdid besm li9dim bech ye5ou blastou
}
