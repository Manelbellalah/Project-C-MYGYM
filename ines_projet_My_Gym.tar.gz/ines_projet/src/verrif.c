#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "verrif.h"
int verrif(char login[],char passwordentry[])
{
	FILE *f;
	char username[20];
	char password[30];
	int role;
f=fopen("/home/bouguerra/Bureau/projet_final/src/user.txt","r");
if(f!=NULL)
{
	while(fscanf(f,"%s %s %d",username,password,&role)!=EOF)
	{
		if((strcmp(login,username)==0) && strcmp(passwordentry,password)==0)
{
return(role);
}
}
return 0;
}
fclose(f);
}
