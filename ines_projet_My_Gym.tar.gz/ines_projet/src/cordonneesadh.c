#include <stdio.h>
#include <string.h>
#include "cordonneesadh.h"


void ajouter_coordonnees_adherent(coordonneesadh adh)
{
FILE *f;
f=fopen("pp.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",adh.nom,adh.prenom,adh.cin,adh. profession,adh.objectifs,adh.adresse,adh.telephone,adh.mail,adh.poids,adh.typesport);
fclose(f);
}
}
/*Lire et afficher le contenu du fichier */
void afficher_coordonnees_adherent(coordonneesadh adh)
{
FILE *f;
f=fopen("/home/bouguerra/Bureau/ines_projet/src/coordonnees_adherent.txt", "r");  
 
  while (!feof(f))
     {
      fscanf(f,"%s %s %s %s %s %s %s %s %d %s \n", adh.nom,adh.prenom,adh.cin,adh.profession,adh.objectifs,adh.adresse,adh.telephone,adh.mail,&adh.poids,adh.typesport);
      fprintf(f,"nom: %s\n prenom: %s\n cin: %s\n profession: %s\n objectifs: %s\n adresse: %s\n telephone: %s\n mail: %d\n poids: %s\n typesport", adh.nom,adh.prenom,adh.cin,adh.profession,adh.objectifs,adh.adresse,adh.telephone,adh.mail,adh.poids,adh.typesport);
      
     }
fclose(f);
} 
void modifprofiladh(coordonneesadh adh)
{
	FILE *f;
	FILE *ftemp;
	FILE *file_ptr;
        coordonneesadh x;
	f=fopen("/home/bouguerra/Bureau/ines_projet/src/coordonnees_adherent.txt", "r");  
	ftemp=fopen("/home/bouguerra/Bureau/ines_projet/src/pph.txt","w");
	if (f!=NULL)
        if (ftemp!=NULL)
{
	{
    		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",x.nom,x.prenom,x.cin,x.profession,x.objectifs,x.adresse,x.telephone,x.mail,x.poids,x.typesport)!=EOF)
    		{
      			/*if(strcmp(adh.cin,cinn)!=0){
        			fprintf(ftemp,"%s %s %s %s %d %s\n",x.profession,x.adresse,x.telephone,x.mail,x.poids,x.typesport);}

      			else{*/
        			fprintf(ftemp,"%s %s %s %s %s %s %s %s %s %s\n",x.nom,x.prenom,x.cin,adh.profession,adh.objectifs,adh.adresse,adh.telephone,adh.mail,x.poids,adh.typesport);
         	
	          }
        }
}
	fclose(f);
	fclose(ftemp);
	remove("/home/bouguerra/Bureau/ines_projet/src/coordonnees_adherent.txt");
	rename("/home/bouguerra/Bureau/ines_projet/src/pph.txt","/home/bouguerra/Bureau/ines_projet/src/coordonnees_adherent.txt");
}
