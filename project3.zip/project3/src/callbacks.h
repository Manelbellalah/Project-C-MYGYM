#include <gtk/gtk.h>


void
on_adherent_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);


void
on_dieteticien_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);


void
on_retour_admin_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data);


void
on_afficher_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);


void
on_ajout_adherent_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_adherent_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_recherche_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_medecin_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_coach_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_adh_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_adh_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_admin_adh_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_med_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_med_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_admin_med_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_coach_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_coach_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_admin_coach_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_diete_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_diete_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_admin_diete_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_adherent_afficher_clicked    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajoutmedecin_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_medecin_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_cherchermed_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_affmed_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajouter_dieteticien_clicked         (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_chercher_diete_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retout_aff_diete_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_diete_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_coachh_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_ajout_coach_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_chercher_coach_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_aff_coach_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_adherent_tree_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_adherent_tree_clicked      (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_adh_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimer_adh_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_med_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimer_med_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimer_coach_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_coach_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimer_diete_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_diete_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_adherent_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_modadh_adh_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_medecin_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_modmed_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_modiete_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_dieteticien_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_coach_mod_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_modcoach_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_valider_modadh_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_valider_modmed_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_valider_modiete_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_valider_modcoach_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_suppadh_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supp_adh_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_suppmed_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supp_med_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supp_diete_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_suppdiete_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supp_coach_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_suppcoach_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_med_tree_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_tree_med_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_tree_diet_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_affiche_tree_coech_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_tree_coech_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_kine_clicked                        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_affiche_tree_diet_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajouter_kine_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modifier_kine_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_kine_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_kine_admin_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_val_ajoutkine_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_ajout_kine_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_val_cinmodkine_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_val_modkine_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_modkine_kine_clicked         (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimer_cin_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_suppkine_kine_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_tree_kine_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_aff_treekine_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimer_kine_clicked              (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_geration_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

/*void
on_ajout_ges_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);*/

void
on_retour_ajout_ges_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_gest_admin_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supp_ges_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajoutf_ges_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajout_gest_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_aff_ges_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_aff_tree_gest_clicked               (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_mod_ges_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_modf_gest_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_val_cin_mod_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_mod_gest_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_gest_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_supp_gest_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_suppf_gest_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supp_gest_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_loginn_clicked                      (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_mygim_admin_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_deconnection_admin_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_aff_plan_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_deconnection_coach_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_affich_deal_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_aff_event_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);
