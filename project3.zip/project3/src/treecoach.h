#include <gtk/gtk.h>
#include "fonctionm.h"

void affichercoach(GtkWidget *treeview);
