#include <gtk/gtk.h>
#include "fonctionm.h"

void afficheracceuil(GtkWidget *treeview);
