#include <gtk/gtk.h>
#include "fonctionm.h"

void afficher(GtkWidget *treeview);
