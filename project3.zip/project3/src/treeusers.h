#include <gtk/gtk.h>
#include "fonctionm.h"

void affichergest(GtkWidget *treeview);
