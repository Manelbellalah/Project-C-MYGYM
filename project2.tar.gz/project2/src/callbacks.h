#include <gtk/gtk.h>
void
on_button1_clicked (GtkWidget       *widget, gpointer         user_data);

void
on_button2m_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_3_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_patient_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


                                       
void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton      *objet,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button13_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);



void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
