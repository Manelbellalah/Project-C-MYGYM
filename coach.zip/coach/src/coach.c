
#include <stdio.h>
#include <stdlib.h>
#include "coach.h"
#include <string.h>
geration verifier (char cin1[30], char password1[30])
{

	FILE *f;
	geration c;
f=fopen("user.txt","r");
if(f!=NULL)
{
	while(fscanf(f,"%s %s %s %s %s",c.nom,c.prenom,c.cin,c.role,c.moddepasse)!=EOF)
	{
		if((strcmp(cin1,c.cin)==0) && (strcmp(password1,c.moddepasse)==0))
{
return(c);
}
fclose(f);


/*else
{
fclose(f);
return 0;
}*/
}
}

}
coach readprofile(char nom1[30],char prenom1[30])
{
FILE *f;
coach c;
//coach c1;
f=fopen("profilcoach.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s",c.nom,c.prenom,c.sexe,c.cin,c.numero,c.specialite)!=EOF)
{
if((strcmp(nom1,c.nom)==0) && (strcmp(prenom1,c.prenom)==0))
return (c);}
}
fclose(f);
}

void editprofilec(coach c1)
{
FILE*f;
FILE*f1;
coach c;
f=fopen("profilcoach.txt","r");
f1=fopen("profilcoach1.txt","w");
if(f!=NULL)
{
if(f1!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s",c.nom,c.prenom,c.sexe,c.cin,c.numero,c.specialite)!=EOF)
{ 
if(strcmp(c1.cin,c.cin)==0)
{
fprintf(f1,"%s %s %s %s %s %s",c1.nom,c1.prenom,c.sexe,c.cin,c1.numero,c1.specialite);

}
else
{
fprintf(f1,"%s %s %s %s %s %s",c.nom,c.prenom,c.sexe,c.cin,c.numero,c.specialite);
}

}
}
}
fclose(f);
fclose(f1);
remove("profilcoach.txt");
rename("profilcoach1.txt","profilcoach.txt");
}
void edituserc(geration c1)
{
FILE*f;
FILE*f1;
geration c;
f=fopen("user.txt","r");
f1=fopen("user1.txt","w");
if(f!=NULL)
{
if(f1!=NULL)
{
while(fscanf(f,"%s %s %s %s %s",c.nom,c.prenom,c.cin,c.role,c.moddepasse)!=EOF)
{ 
if(strcmp(c1.cin,c.cin)==0)
{
fprintf(f1,"%s %s %s %s %s",c1.nom,c1.prenom,c.cin,c.role,c.moddepasse);

}
else
{
fprintf(f1,"%s %s %s %s %s",c.nom,c.prenom,c.cin,c.role,c.moddepasse);
}

}
}
}
fclose(f);
fclose(f1);
remove("user.txt");
rename("user1.txt","user.txt");
}
void writeplan(plan c)
{
FILE *f;
//if(f!=NULL)

f=fopen("plancoach.txt","w");
/*if(f!=NULL)
{*/
/*fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",c.nom,c.l8,c.l10,c.l14,c.l16,c.ma8,c.ma10,c.ma14,c.ma16,c.me8,c.me10,c.me14,c.me16,c.j8,c.j10,c.j14,c.j16,c.v8,c.v10,c.v14,c.v16,c.s8,c.s10,c.s14,c.s16);*/
fprintf(f,"%s %s %s %s\n",c.l8,c.l10,c.l14,c.l16);
fprintf(f,"%s %s %s %s\n",c.ma8,c.ma10,c.ma14,c.ma16);
fprintf(f,"%s %s %s %s\n",c.me8,c.me10,c.me14,c.me16);
fprintf(f,"%s %s %s %s\n",c.j8,c.j10,c.j14,c.j16);
fprintf(f,"%s %s %s %s\n",c.v8,c.v10,c.v14,c.v16);
fprintf(f,"%s %s %s %s",c.s8,c.s10,c.s14,c.s16);
//}
fclose(f);
}






void editdispoc(dispc c1)
{
FILE*f;
FILE*f1;
dispc c;
f=fopen("dispcoach.txt","r");
f1=fopen("dispcoach1.txt","w");
if(f!=NULL)
{
if(f1!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",c.cin,c.l8,c.l10,c.l14,c.l16,c.ma8,c.ma10,c.ma14,c.ma16,c.me8,c.me10,c.me14,c.me16,c.j8,c.j10,c.j14,c.j16,c.v8,c.v10,c.v14,c.v16,c.s8,c.s10,c.s14,c.s16)!=EOF)
{
if(strcmp(c1.cin,c.cin)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",c.cin,c1.l8,c1.l10,c1.l14,c1.l16,c1.ma8,c1.ma10,c1.ma14,c1.ma16,c1.me8,c1.me10,c1.me14,c1.me16,c1.j8,c1.j10,c1.j14,c1.j16,c1.v8,c1.v10,c1.v14,c1.v16,c1.s8,c1.s10,c1.s14,c1.s16);

}
else
{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",c.cin,c.l8,c.l10,c.l14,c.l16,c.ma8,c.ma10,c.ma14,c.ma16,c.me8,c.me10,c.me14,c.me16,c.j8,c.j10,c.j14,c.j16,c.v8,c.v10,c.v14,c.v16,c.s8,c.s10,c.s14,c.s16);

}
}
}
}
fclose(f);
fclose(f1);
remove("dispcoach.txt");
rename("dispcoach1.txt","dispcoach.txt");
}
dispc readdisp(char nom1[30])
{
	FILE*f;
	dispc c;

f=fopen("dispcoach.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",c.cin,c.l8,c.l10,c.l14,c.l16,c.ma8,c.ma10,c.ma14,c.ma16,c.me8,c.me10,c.me14,c.me16,c.j8,c.j10,c.j14,c.j16,c.v8,c.v10,c.v14,c.v16,c.s8,c.s10,c.s14,c.s16)!=EOF)
{
if(strcmp(nom1,c.cin)==0)
{
return(c);
}
}
}
fclose(f);
}
coach readcin(char cin[30])
{
FILE *f;
coach c;
//coach c1;
f=fopen("profilcoach.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s",c.nom,c.prenom,c.sexe,c.cin,c.numero,c.specialite)!=EOF)
{
if(strcmp(cin,c.cin)==0) 
return (c);}
}
fclose(f);
}
plan readplanc(char nom1[30])
{
	FILE*f;
	plan c;

f=fopen("plancoach.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",c.l8,c.l10,c.l14,c.l16,c.ma8,c.ma10,c.ma14,c.ma16,c.me8,c.me10,c.me14,c.me16,c.j8,c.j10,c.j14,c.j16,c.v8,c.v10,c.v14,c.v16,c.s8,c.s10,c.s14,c.s16)!=EOF)
{
return(c);
}
}
fclose(f);
}












