#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "coach.h"

int main()
{

FILE *f;
prof c;

f=fopen("/home/oussama/Projects/coach/fichierapp/ajouter","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { //si le fichier est ouvert
//Ajout de 10 personnes
printf("Saisir les données");
fflush(stdin);
gets(c.nom);
fflush(stdin);
gets(c.prenom);
fflush(stdin);
gets(c.passe);
gets(c.cin);

scanf("%d",&c.role);

fprintf(f,"%s %s %d %d %s \n",c.nom,c.prenom,c.cin,c.role,c.passe);//écriture dans le fichier

fclose(f); //fermeture du fichier
}
return 0;

}

