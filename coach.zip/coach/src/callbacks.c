#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "coach.h"
#include <string.h>
#include "treeplanningc.h"

void
on_loginc_clicked                      (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *auth;
GtkWidget *acccoach;
GtkWidget *cinc;
GtkWidget *passc;
GtkWidget *bienc;
GtkWidget *nomcc;
GtkWidget *prenomcc;
GtkWidget *acc;

char cin[30];
char password[30];
geration x;
auth=lookup_widget(graphic,"authentification");
cinc=lookup_widget(graphic,"cincc");
passc=lookup_widget(graphic,"passc");
bienc=lookup_widget(graphic,"bienc");
//acc=lookup_widget(graphic,"acccoach");
acccoach=create_acccoach();
nomcc=lookup_widget(acccoach,"nomc");
prenomcc=lookup_widget(acccoach,"prenomc");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(cinc)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(passc)));

x=verifier(cin,password);
if (strcmp(x.role,"3")==0)
{

 gtk_widget_show(acccoach);
gtk_widget_hide(auth);



gtk_entry_set_text(GTK_ENTRY(nomcc),x.nom);
gtk_entry_set_text(GTK_ENTRY(prenomcc),x.prenom);
}
else
{
gtk_label_set_text(GTK_LABEL(bienc),"Wrong PASSWORD and/or USER ID.");
}

}


void
on_logoutc_clicked                     (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *authentification;
GtkWidget *profc;
profc=lookup_widget(graphic,"acccoach");
authentification=create_authentification();
 gtk_widget_show(authentification);
gtk_widget_hide(profc);
}


void
on_profilc_clicked                     (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *editerprofilec;
GtkWidget *profc;
GtkWidget *nomc1;
GtkWidget *prenomc1;
GtkWidget *nomco;
GtkWidget *prenomco;
GtkWidget *cinco;
GtkWidget *cinre1;
GtkWidget *sexeco;

GtkWidget *numco;
GtkWidget *specco;
GtkWidget *specco1;
GtkWidget *specco2;
GtkWidget *acccoach;

char nom1[30];
char prenom1[30];
coach x;
int y;
profc=lookup_widget(graphic,"acccoach");

nomc1=lookup_widget(graphic,"nomc");
prenomc1=lookup_widget(graphic,"prenomc");
strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nomc1)));
strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenomc1)));

editerprofilec=create_editerprofilec();
nomco=lookup_widget(editerprofilec,"nom1c");
prenomco=lookup_widget(editerprofilec,"prenom1c");
cinco=lookup_widget(editerprofilec,"cin1c");
cinre1=lookup_widget(editerprofilec,"cinre");
sexeco=lookup_widget(editerprofilec,"sexe1c");
numco=lookup_widget(editerprofilec,"num1c");
specco1=lookup_widget(editerprofilec,"specialitecoach1");
specco2=lookup_widget(editerprofilec,"spec1c");
x=readprofile(nom1,prenom1);
gtk_widget_show(editerprofilec);
gtk_widget_hide(profc);



gtk_entry_set_text(GTK_ENTRY(nomco),x.nom);
gtk_entry_set_text(GTK_ENTRY(prenomco),x.prenom);
gtk_label_set_text(GTK_LABEL(cinco),x.cin);
gtk_entry_set_text(GTK_ENTRY(cinre1),x.cin);
gtk_label_set_text(GTK_LABEL(sexeco),x.sexe);

gtk_entry_set_text(GTK_ENTRY(numco),x.numero);

gtk_label_set_text(GTK_LABEL(specco1),x.specialite);
y=4;
if (strcmp(x.specialite,"Musculation")==0)
y=1;
else if (strcmp(x.specialite,"Airobic")==0)
y=2;
else if (strcmp(x.specialite,"Fitness")==0)
y=3;
else if (strcmp(x.specialite,"KingBoxing")==0)
y=4;

gtk_combo_box_set_active(GTK_COMBO_BOX(specco2),y);

}


void
on_planc_clicked                       (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *plancoach;
GtkWidget *acccoach;
GtkWidget *nom1c;
GtkWidget *prenom1c;
GtkWidget *nom2c;
GtkWidget *profc;
GtkWidget *tree;
char nom[30];
char prenom[30];
char cinc2[30];
coach y;
nom1c=lookup_widget(graphic,"nomc");
prenom1c=lookup_widget(graphic,"prenomc");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(nom1c)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(prenom1c)));
y=readprofile(nom,prenom);
strcpy(cinc2,y.cin);
profc=lookup_widget(graphic,"acccoach");
plancoach=create_plancoach();
nom2c=lookup_widget(plancoach,"nomplanc");
tree=lookup_widget(plancoach,"affplanc");
afficherplanningc(tree);

gtk_widget_show(plancoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom2c),y.cin);



}


void
on_dispc_clicked                       (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *dispcoach;
GtkWidget *acccoach;
GtkWidget *nom1c;
GtkWidget *nom2c;
GtkWidget *prenom1c;
GtkWidget *profc;
GtkWidget *l8;
GtkWidget *l10;
GtkWidget *l14;
GtkWidget *l16;
GtkWidget *ma8;
GtkWidget *ma10;
GtkWidget *ma14;
GtkWidget *ma16;
GtkWidget *me8;
GtkWidget *me10;
GtkWidget *me14;
GtkWidget *me16;
GtkWidget *j8;
GtkWidget *j10;
GtkWidget *j14;
GtkWidget *j16;
GtkWidget *v8;
GtkWidget *v10;
GtkWidget *v14;
GtkWidget *v16;
GtkWidget *s8;
GtkWidget *s10;
GtkWidget *s14;
GtkWidget *s16;
dispc c;
coach y;
char nom[30];
char prenom[30];
char cinc2[30];
profc=lookup_widget(graphic,"acccoach");
nom1c=lookup_widget(graphic,"nomc");
prenom1c=lookup_widget(graphic,"prenomc");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(nom1c)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(prenom1c)));
y=readprofile(nom,prenom);
strcpy(cinc2,y.cin);
dispcoach=create_dispcoach();
nom2c=lookup_widget(dispcoach,"nomdispc");
 


l8=lookup_widget(dispcoach,"l81c");
l10=lookup_widget(dispcoach,"l101c");
l14=lookup_widget(dispcoach,"l141c");
l16=lookup_widget(dispcoach,"l161c");
ma8=lookup_widget(dispcoach,"ma81c");
ma10=lookup_widget(dispcoach,"ma101c");
ma14=lookup_widget(dispcoach,"ma141c");
ma16=lookup_widget(dispcoach,"ma161c");
me8=lookup_widget(dispcoach,"me81c");
me10=lookup_widget(dispcoach,"me101c");
me14=lookup_widget(dispcoach,"me141c");
me16=lookup_widget(dispcoach,"me161c");
j8=lookup_widget(dispcoach,"j81c");
j10=lookup_widget(dispcoach,"j101c");
j14=lookup_widget(dispcoach,"j141c");
j16=lookup_widget(dispcoach,"j161c");
v8=lookup_widget(dispcoach,"v81c");
v10=lookup_widget(dispcoach,"v101c");
v14=lookup_widget(dispcoach,"v141c");
v16=lookup_widget(dispcoach,"v161c");
s8=lookup_widget(dispcoach,"s81c");
s10=lookup_widget(dispcoach,"s101c");
s14=lookup_widget(dispcoach,"s141c");
s16=lookup_widget(dispcoach,"s161c");
c=readdisp(cinc2);
gtk_widget_show(dispcoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom2c),c.cin);
gtk_label_set_text(GTK_LABEL(l8),c.l8);
gtk_label_set_text(GTK_LABEL(l10),c.l10);
gtk_label_set_text(GTK_LABEL(l14),c.l14);
gtk_label_set_text(GTK_LABEL(l16),c.l16);
gtk_label_set_text(GTK_LABEL(ma8),c.ma8);
gtk_label_set_text(GTK_LABEL(ma10),c.ma10);
gtk_label_set_text(GTK_LABEL(ma14),c.ma14);
gtk_label_set_text(GTK_LABEL(ma16),c.ma16);
gtk_label_set_text(GTK_LABEL(me8),c.me8);
gtk_label_set_text(GTK_LABEL(me10),c.me10);
gtk_label_set_text(GTK_LABEL(me14),c.me14);
gtk_label_set_text(GTK_LABEL(me16),c.me16);
gtk_label_set_text(GTK_LABEL(j8),c.j8);
gtk_label_set_text(GTK_LABEL(j10),c.j10);
gtk_label_set_text(GTK_LABEL(j14),c.j14);
gtk_label_set_text(GTK_LABEL(j16),c.j16);
gtk_label_set_text(GTK_LABEL(v8),c.v8);
gtk_label_set_text(GTK_LABEL(v10),c.v10);
gtk_label_set_text(GTK_LABEL(v14),c.v14);
gtk_label_set_text(GTK_LABEL(v16),c.v16);
gtk_label_set_text(GTK_LABEL(s8),c.s8);
gtk_label_set_text(GTK_LABEL(s10),c.s10);
gtk_label_set_text(GTK_LABEL(s14),c.s14);
gtk_label_set_text(GTK_LABEL(s16),c.s16);

}


void
on_editprofilc_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data)
{
/*GtkWidget *profc;
GtkWidget *editerprofilec;
GtkWidget *nomc1;
GtkWidget *prenomc1;
GtkWidget *sexec1;
GtkWidget *cinc1;
char nom1[30];
char prenom1[30];
coach x;
nomc1=lookup_widget(graphic,"nomc");
prenomc1=lookup_widget(graphic,"prenomc");
profc=lookup_widget(graphic,"gprofilc");
editerprofilec=create_editerprofilec();
 gtk_widget_show(editerprofilec);
gtk_widget_hide(profc);
strcpy(nom1,gtk_label_get_text(GTK_LABEL(nomc1)));
strcpy(prenom1,gtk_label_get_text(GTK_LABEL(prenomc1)));
x=readprofile(nom1,prenom1);
sexec1=lookup_widget(graphic,"sexe1c");
cinc1=lookup_widget(graphic,"cin1c");
gtk_label_set_text(GTK_LABEL(sexec1),x.sexe);
gtk_label_set_text(GTK_LABEL(cinc1),x.cin);*/
}
void
on_retourcp_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data)
{
/*GtkWidget *profc;
GtkWidget *acccoach;
profc=lookup_widget(graphic,"gprofilc");
acccoach=create_acccoach();
 gtk_widget_show(acccoach);
gtk_widget_hide(profc);*/
}

void
on_validprofilec_clicked               (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *editerprofilec;
GtkWidget *nomc1;
GtkWidget *prenomc1;
GtkWidget *numc1;
GtkWidget *specc1;
GtkWidget *sexec1;
GtkWidget *cinc1;
GtkWidget *cinre1;
coach x;
geration c;
//editerprofilec=create_editerprofilec();
nomc1=lookup_widget(graphic,"nom1c");
prenomc1=lookup_widget(graphic,"prenom1c");
numc1=lookup_widget(graphic,"num1c");
specc1=lookup_widget(graphic,"spec1c");
sexec1=lookup_widget(graphic,"sexe1c");
cinc1=lookup_widget(graphic,"cin1c");
cinre1=lookup_widget(graphic,"cinre");
strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(nomc1)));
strcpy(x.prenom,gtk_entry_get_text(GTK_ENTRY(prenomc1)));
strcpy(x.numero,gtk_entry_get_text(GTK_ENTRY(numc1)));
strcpy(x.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(specc1)));
strcpy(x.cin,gtk_entry_get_text(GTK_ENTRY(cinre1)));
//strcpy(x.sexe,gtk_label_get_text(GTK_LABEL(sexec1)));
//strcpy(x.cin,gtk_label_get_text(GTK_LABEL(cinc1)));
editprofilec(x);
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(nomc1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(prenomc1)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(cinre1)));
//strcpy(c.cin,gtk_label_get_text(GTK_LABEL(cinc1)));
edituserc(c);


}


void
on_retourpc_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *acccoach;
GtkWidget *profc;
GtkWidget *nomc1;
GtkWidget *prenomc1;
GtkWidget *nom1c;
GtkWidget *prenom1c;
char nom[30];
char prenom[30];
profc=lookup_widget(graphic,"editerprofilec");
nomc1=lookup_widget(graphic,"nom1c");
prenomc1=lookup_widget(graphic,"prenom1c");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(nomc1)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(prenomc1)));

acccoach=create_acccoach();
nom1c=lookup_widget(acccoach,"nomc");
prenom1c=lookup_widget(acccoach,"prenomc");

gtk_widget_show(acccoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom1c),nom);
gtk_entry_set_text(GTK_ENTRY(prenom1c),prenom);
}


void
on_editdispc_clicked                   (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *profc;
GtkWidget *editerdispc;
GtkWidget *nom1c;
GtkWidget *nom2c;
GtkWidget *l8;
GtkWidget *l10;
GtkWidget *l14;
GtkWidget *l16;
GtkWidget *ma8;
GtkWidget *ma10;
GtkWidget *ma14;
GtkWidget *ma16;
GtkWidget *me8;
GtkWidget *me10;
GtkWidget *me14;
GtkWidget *me16;
GtkWidget *j8;
GtkWidget *j10;
GtkWidget *j14;
GtkWidget *j16;
GtkWidget *v8;
GtkWidget *v10;
GtkWidget *v14;
GtkWidget *v16;
GtkWidget *s8;
GtkWidget *s10;
GtkWidget *s14;
GtkWidget *s16;
char non[30];
dispc c;
int y;
nom1c=lookup_widget(graphic,"nomdispc");
strcpy(non,gtk_entry_get_text(GTK_ENTRY(nom1c)));
profc=lookup_widget(graphic,"dispcoach");
editerdispc=create_editerdispc();
nom2c=lookup_widget(editerdispc,"nomedispc");
l8=lookup_widget(editerdispc,"lu81c");
l10=lookup_widget(editerdispc,"lu101c");
l14=lookup_widget(editerdispc,"lu141c");
l16=lookup_widget(editerdispc,"lu161c");
ma8=lookup_widget(editerdispc,"mar81c");
ma10=lookup_widget(editerdispc,"mar101c");
ma14=lookup_widget(editerdispc,"mar141c");
ma16=lookup_widget(editerdispc,"mar161c");
me8=lookup_widget(editerdispc,"mer81c");
me10=lookup_widget(editerdispc,"mer101c");
me14=lookup_widget(editerdispc,"mer141c");
me16=lookup_widget(editerdispc,"mer161c");
j8=lookup_widget(editerdispc,"je81c");
j10=lookup_widget(editerdispc,"je101c");
j14=lookup_widget(editerdispc,"je141c");
j16=lookup_widget(editerdispc,"je161c");
v8=lookup_widget(editerdispc,"ve81c");
v10=lookup_widget(editerdispc,"ve101c");
v14=lookup_widget(editerdispc,"ve141c");
v16=lookup_widget(editerdispc,"ve161c");
s8=lookup_widget(editerdispc,"sa81c");
s10=lookup_widget(editerdispc,"sa101c");
s14=lookup_widget(editerdispc,"sa141c");
s16=lookup_widget(editerdispc,"sa161c");
c=readdisp(non);
 gtk_widget_show(editerdispc);
gtk_widget_hide(profc);

gtk_entry_set_text(GTK_ENTRY(nom2c),non);
if(strcmp(c.l8,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(l8),y);
if(strcmp(c.l10,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(l10),y);
if(strcmp(c.l14,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(l14),y);
if(strcmp(c.l16,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(l16),y);
if(strcmp(c.ma8,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma8),y);
if(strcmp(c.ma10,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma10),y);
if(strcmp(c.ma14,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma14),y);
if(strcmp(c.ma16,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma16),y);
if(strcmp(c.me8,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(me8),y);
if(strcmp(c.me10,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(me10),y);
if(strcmp(c.me14,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(me14),y);
if(strcmp(c.me16,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(me16),y);
if(strcmp(c.j8,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(j8),y);
if(strcmp(c.j10,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(j10),y);
if(strcmp(c.j14,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(j14),y);
if(strcmp(c.j16,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(j16),y);
if(strcmp(c.v8,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(v8),y);
if(strcmp(c.v10,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(v10),y);
if(strcmp(c.v14,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(v14),y);
if(strcmp(c.v16,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(v16),y);
if(strcmp(c.s8,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(s8),y);
if(strcmp(c.s10,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(s10),y);
if(strcmp(c.s14,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(s14),y);
if(strcmp(c.s16,"Disponible")==0)
y=1;
else
y=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(s16),y);

}


void
on_retourcdis_clicked                  (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *profc;
GtkWidget *acccoach;
GtkWidget *cin1c;
GtkWidget *nom1;
GtkWidget *prenom1;
char cin [30];
coach x;
profc=lookup_widget(graphic,"dispcoach");
cin1c=lookup_widget(graphic,"nomdispc");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(cin1c)));
x=readcin(cin);

acccoach=create_acccoach();
nom1=lookup_widget(acccoach,"nomc");
prenom1=lookup_widget(acccoach,"prenomc");
gtk_widget_show(acccoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom1),x.nom);
gtk_entry_set_text(GTK_ENTRY(prenom1),x.prenom);

}


void
on_valdispc_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *editt;
GtkWidget *nom1c;
GtkWidget *l8;
GtkWidget *l10;
GtkWidget *l14;
GtkWidget *l16;
GtkWidget *ma8;
GtkWidget *ma10;
GtkWidget *ma14;
GtkWidget *ma16;
GtkWidget *me8;
GtkWidget *me10;
GtkWidget *me14;
GtkWidget *me16;
GtkWidget *j8;
GtkWidget *j10;
GtkWidget *j14;
GtkWidget *j16;
GtkWidget *v8;
GtkWidget *v10;
GtkWidget *v14;
GtkWidget *v16;
GtkWidget *s8;
GtkWidget *s10;
GtkWidget *s14;
GtkWidget *s16;
dispc c;
//editt=lookup_widget(graphic,"editerdispc");
nom1c=lookup_widget(graphic,"nomedispc");

l8=lookup_widget(graphic,"lu81c");
l10=lookup_widget(graphic,"lu101c");
l14=lookup_widget(graphic,"lu141c");
l16=lookup_widget(graphic,"lu161c");
ma8=lookup_widget(graphic,"mar81c");
ma10=lookup_widget(graphic,"mar101c");
ma14=lookup_widget(graphic,"mar141c");
ma16=lookup_widget(graphic,"mar161c");
me8=lookup_widget(graphic,"mer81c");
me10=lookup_widget(graphic,"mer101c");
me14=lookup_widget(graphic,"mer141c");
me16=lookup_widget(graphic,"mer161c");
j8=lookup_widget(graphic,"je81c");
j10=lookup_widget(graphic,"je101c");
j14=lookup_widget(graphic,"je141c");
j16=lookup_widget(graphic,"je161c");
v8=lookup_widget(graphic,"ve81c");
v10=lookup_widget(graphic,"ve101c");
v14=lookup_widget(graphic,"ve141c");
v16=lookup_widget(graphic,"ve161c");
s8=lookup_widget(graphic,"sa81c");
s10=lookup_widget(graphic,"sa101c");
s14=lookup_widget(graphic,"sa141c");
s16=lookup_widget(graphic,"sa161c");
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(nom1c)));
strcpy(c.l8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l8)));
strcpy(c.l10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l10)));
strcpy(c.l14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l14)));
strcpy(c.l16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l16)));
strcpy(c.ma8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma8)));
strcpy(c.ma10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma10)));
strcpy(c.ma14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma14)));
strcpy(c.ma16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma16)));
strcpy(c.me8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me8)));
strcpy(c.me10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me10)));
strcpy(c.me14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me14)));
strcpy(c.me16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me16)));
strcpy(c.j8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j8)));
strcpy(c.j10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j10)));
strcpy(c.j14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j14)));
strcpy(c.j16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j16)));
strcpy(c.v8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v8)));
strcpy(c.v10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v10)));
strcpy(c.v14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v14)));
strcpy(c.v16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v16)));
strcpy(c.s8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s8)));
strcpy(c.s10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s10)));
strcpy(c.s14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s14)));
strcpy(c.s16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s16)));
editdispoc(c);
}

void
on_retourdispc_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *profc;
GtkWidget *dispcoach;
GtkWidget *cin1c;
GtkWidget *cinc1;
GtkWidget *l8;
GtkWidget *l10;
GtkWidget *l14;
GtkWidget *l16;
GtkWidget *ma8;
GtkWidget *ma10;
GtkWidget *ma14;
GtkWidget *ma16;
GtkWidget *me8;
GtkWidget *me10;
GtkWidget *me14;
GtkWidget *me16;
GtkWidget *j8;
GtkWidget *j10;
GtkWidget *j14;
GtkWidget *j16;
GtkWidget *v8;
GtkWidget *v10;
GtkWidget *v14;
GtkWidget *v16;
GtkWidget *s8;
GtkWidget *s10;
GtkWidget *s14;
GtkWidget *s16;
char cin[30];
dispc c;
profc=lookup_widget(graphic,"editerdispc");
cin1c=lookup_widget(graphic,"nomedispc");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(cin1c)));
dispcoach=create_dispcoach();
cinc1=lookup_widget(dispcoach,"nomdispc");
l8=lookup_widget(dispcoach,"l81c");
l10=lookup_widget(dispcoach,"l101c");
l14=lookup_widget(dispcoach,"l141c");
l16=lookup_widget(dispcoach,"l161c");
ma8=lookup_widget(dispcoach,"ma81c");
ma10=lookup_widget(dispcoach,"ma101c");
ma14=lookup_widget(dispcoach,"ma141c");
ma16=lookup_widget(dispcoach,"ma161c");
me8=lookup_widget(dispcoach,"me81c");
me10=lookup_widget(dispcoach,"me101c");
me14=lookup_widget(dispcoach,"me141c");
me16=lookup_widget(dispcoach,"me161c");
j8=lookup_widget(dispcoach,"j81c");
j10=lookup_widget(dispcoach,"j101c");
j14=lookup_widget(dispcoach,"j141c");
j16=lookup_widget(dispcoach,"j161c");
v8=lookup_widget(dispcoach,"v81c");
v10=lookup_widget(dispcoach,"v101c");
v14=lookup_widget(dispcoach,"v141c");
v16=lookup_widget(dispcoach,"v161c");
s8=lookup_widget(dispcoach,"s81c");
s10=lookup_widget(dispcoach,"s101c");
s14=lookup_widget(dispcoach,"s141c");
s16=lookup_widget(dispcoach,"s161c");
c=readdisp(cin);
gtk_widget_show(dispcoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(cinc1),cin);
gtk_label_set_text(GTK_LABEL(l8),c.l8);
gtk_label_set_text(GTK_LABEL(l10),c.l10);
gtk_label_set_text(GTK_LABEL(l14),c.l14);
gtk_label_set_text(GTK_LABEL(l16),c.l16);
gtk_label_set_text(GTK_LABEL(ma8),c.ma8);
gtk_label_set_text(GTK_LABEL(ma10),c.ma10);
gtk_label_set_text(GTK_LABEL(ma14),c.ma14);
gtk_label_set_text(GTK_LABEL(ma16),c.ma16);
gtk_label_set_text(GTK_LABEL(me8),c.me8);
gtk_label_set_text(GTK_LABEL(me10),c.me10);
gtk_label_set_text(GTK_LABEL(me14),c.me14);
gtk_label_set_text(GTK_LABEL(me16),c.me16);
gtk_label_set_text(GTK_LABEL(j8),c.j8);
gtk_label_set_text(GTK_LABEL(j10),c.j10);
gtk_label_set_text(GTK_LABEL(j14),c.j14);
gtk_label_set_text(GTK_LABEL(j16),c.j16);
gtk_label_set_text(GTK_LABEL(v8),c.v8);
gtk_label_set_text(GTK_LABEL(v10),c.v10);
gtk_label_set_text(GTK_LABEL(v14),c.v14);
gtk_label_set_text(GTK_LABEL(v16),c.v16);
gtk_label_set_text(GTK_LABEL(s8),c.s8);
gtk_label_set_text(GTK_LABEL(s10),c.s10);
gtk_label_set_text(GTK_LABEL(s14),c.s14);
gtk_label_set_text(GTK_LABEL(s16),c.s16);

 
}


void
on_editplanc_clicked                   (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *profc;
GtkWidget *editerplanc;
GtkWidget *nom1c;
GtkWidget *nom2c;
GtkWidget *l8;
GtkWidget *l10;
GtkWidget *l14;
GtkWidget *l16;
GtkWidget *ma8;
GtkWidget *ma10;
GtkWidget *ma14;
GtkWidget *ma16;
GtkWidget *me8;
GtkWidget *me10;
GtkWidget *me14;
GtkWidget *me16;
GtkWidget *j8;
GtkWidget *j10;
GtkWidget *j14;
GtkWidget *j16;
GtkWidget *v8;
GtkWidget *v10;
GtkWidget *v14;
GtkWidget *v16;
GtkWidget *s8;
GtkWidget *s10;
GtkWidget *s14;
GtkWidget *s16;
char non[30];
char var[30];
int y;
plan c;
nom1c=lookup_widget(graphic,"nomplanc");
strcpy(non,gtk_entry_get_text(GTK_ENTRY(nom1c)));
profc=lookup_widget(graphic,"plancoach");

editerplanc=create_editerplanc();
nom2c=lookup_widget(editerplanc,"nomeplanc");
l8=lookup_widget(editerplanc,"lu8c");
l10=lookup_widget(editerplanc,"lu10c");
l14=lookup_widget(editerplanc,"lu14c");
l16=lookup_widget(editerplanc,"lu16c");
ma8=lookup_widget(editerplanc,"mar8c");
ma10=lookup_widget(editerplanc,"mar10c");
ma14=lookup_widget(editerplanc,"mar14c");
ma16=lookup_widget(editerplanc,"mar16c");
me8=lookup_widget(editerplanc,"mer8c");
me10=lookup_widget(editerplanc,"mer10c");
me14=lookup_widget(editerplanc,"mer14c");
me16=lookup_widget(editerplanc,"mer16c");
j8=lookup_widget(editerplanc,"je8c");
j10=lookup_widget(editerplanc,"je10c");
j14=lookup_widget(editerplanc,"je14c");
j16=lookup_widget(editerplanc,"je16c");
v8=lookup_widget(editerplanc,"ve8c");
v10=lookup_widget(editerplanc,"ve10c");
v14=lookup_widget(editerplanc,"ve14c");
v16=lookup_widget(editerplanc,"ve16c");
s8=lookup_widget(editerplanc,"sa8c");
s10=lookup_widget(editerplanc,"sa10c");
s14=lookup_widget(editerplanc,"sa14c");
s16=lookup_widget(editerplanc,"sa16c");
c=readplanc(non);
 gtk_widget_show(editerplanc);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom2c),non);
if(strcmp(c.l8,"Musculation")==0)
y=2;
else if(strcmp(c.l8,"Airobic")==0)
y=3;
else if(strcmp(c.l8,"Fitness")==0)
y=4;
else if(strcmp(c.l8,"KingBoxing")==0)
y=5;
else
y=0;
gtk_combo_box_set_active(GTK_COMBO_BOX(l8),y);
if(strcmp(c.l10,"Musculation")==0)
y=2;
else if(strcmp(c.l10,"Airobic")==0)
y=3;
else if(strcmp(c.l10,"Fitness")==0)
y=4;
else if(strcmp(c.l10,"KingBoxing")==0)
y=5;
else
y=0;
gtk_combo_box_set_active(GTK_COMBO_BOX(l10),y);
strcpy(var,c.l14);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(l14),y);
strcpy(var,c.l16);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(l16),y);
strcpy(var,c.ma8);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma8),y);
strcpy(var,c.ma10);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma10),y);
strcpy(var,c.ma14);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma14),y);
strcpy(var,c.ma16);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(ma16),y);
strcpy(var,c.me8);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(me8),y);
strcpy(var,c.me10);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(me10),y);
strcpy(var,c.me14);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(me14),y);
strcpy(var,c.me16);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(me16),y);
strcpy(var,c.j8);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(j8),y);
strcpy(var,c.j10);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(j10),y);
strcpy(var,c.j14);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(j14),y);
strcpy(var,c.j16);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(j16),y);
strcpy(var,c.v8);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(v8),y);
strcpy(var,c.v10);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(v10),y);
strcpy(var,c.v14);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(v14),y);
strcpy(var,c.v16);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(v16),y);
strcpy(var,c.s8);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(s8),y);
strcpy(var,c.s10);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(s10),y);
strcpy(var,c.s14);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(s14),y);
strcpy(var,c.s16);
if(strcmp(var,"Musculation")==0)
y=2;
else if(strcmp(var,"Airobic")==0)
y=3;
else if(strcmp(var,"Fitness")==0)
y=4;
else if(strcmp(var,"KingBoxing")==0)
y=5;
else
y=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(s16),y);

}


void
on_retourcplan_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *profc;
GtkWidget *acccoach;
GtkWidget *cinc;
GtkWidget *nom1;
GtkWidget *prenom1;

char cin[30];
coach c;
profc=lookup_widget(graphic,"plancoach");
cinc=lookup_widget(graphic,"nomplanc");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(cinc)));
c=readcin(cin);
acccoach=create_acccoach();
nom1=lookup_widget(acccoach,"nomc");
prenom1=lookup_widget(acccoach,"prenomc");
 gtk_widget_show(acccoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom1),c.nom);
gtk_entry_set_text(GTK_ENTRY(prenom1),c.prenom);

}


void
on_valplanc_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data)
{
plan c;
//GtkWidget *editerplanc;
GtkWidget *l8;
GtkWidget *l10;
GtkWidget *l14;
GtkWidget *l16;
GtkWidget *ma8;
GtkWidget *ma10;
GtkWidget *ma14;
GtkWidget *ma16;
GtkWidget *me8;
GtkWidget *me10;
GtkWidget *me14;
GtkWidget *me16;
GtkWidget *j8;
GtkWidget *j10;
GtkWidget *j14;
GtkWidget *j16;
GtkWidget *v8;
GtkWidget *v10;
GtkWidget *v14;
GtkWidget *v16;
GtkWidget *s8;
GtkWidget *s10;
GtkWidget *s14;
GtkWidget *s16;
GtkWidget *editt;

editt=lookup_widget(graphic,"editerplanc");
l8=lookup_widget(graphic,"lu8c");
l10=lookup_widget(graphic,"lu10c");
l14=lookup_widget(graphic,"lu14c");
l16=lookup_widget(graphic,"lu16c");
ma8=lookup_widget(graphic,"mar8c");
ma10=lookup_widget(graphic,"mar10c");
ma14=lookup_widget(graphic,"mar14c");
ma16=lookup_widget(graphic,"mar16c");
me8=lookup_widget(graphic,"mer8c");
me10=lookup_widget(graphic,"mer10c");
me14=lookup_widget(graphic,"mer14c");
me16=lookup_widget(graphic,"mer16c");
j8=lookup_widget(graphic,"je8c");
j10=lookup_widget(graphic,"je10c");
j14=lookup_widget(graphic,"je14c");
j16=lookup_widget(graphic,"je16c");
v8=lookup_widget(graphic,"ve8c");
v10=lookup_widget(graphic,"ve10c");
v14=lookup_widget(graphic,"ve14c");
v16=lookup_widget(graphic,"ve16c");
s8=lookup_widget(graphic,"sa8c");
s10=lookup_widget(graphic,"sa10c");
s14=lookup_widget(graphic,"sa14c");
s16=lookup_widget(graphic,"sa16c");

strcpy(c.l8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l8)));
strcpy(c.l10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l10)));
strcpy(c.l14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l14)));
strcpy(c.l16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(l16)));
strcpy(c.ma8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma8)));
strcpy(c.ma10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma10)));
strcpy(c.ma14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma14)));
strcpy(c.ma16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ma16)));
strcpy(c.me8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me8)));
strcpy(c.me10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me10)));
strcpy(c.me14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me14)));
strcpy(c.me16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(me16)));
strcpy(c.j8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j8)));
strcpy(c.j10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j10)));
strcpy(c.j14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j14)));
strcpy(c.j16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j16)));
strcpy(c.v8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v8)));
strcpy(c.v10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v10)));
strcpy(c.v14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v14)));
strcpy(c.v16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(v16)));
strcpy(c.s8,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s8)));
strcpy(c.s10,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s10)));
strcpy(c.s14,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s14)));
strcpy(c.s16,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s16)));
writeplan(c);
}



void
on_retourplanc_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data)
{
GtkWidget *plancoach;
GtkWidget *profc;
GtkWidget *nom1c;
GtkWidget *nom2c;
GtkWidget *tree;
char non[30];
nom1c=lookup_widget(graphic,"nomeplanc");
strcpy(non,gtk_entry_get_text(GTK_ENTRY(nom1c)));
profc=lookup_widget(graphic,"editerplanc");
plancoach=create_plancoach();
tree=lookup_widget(plancoach,"affplanc");
afficherplanningc(tree);
nom2c=lookup_widget(plancoach,"nomplanc");
gtk_widget_show(plancoach);
gtk_widget_hide(profc);
gtk_entry_set_text(GTK_ENTRY(nom2c),non);


}




