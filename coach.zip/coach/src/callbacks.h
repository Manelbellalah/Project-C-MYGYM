#include <gtk/gtk.h>


void
on_loginc_clicked                      (GtkWidget       *graphic,
                                        gpointer         user_data);

void
on_logoutc_clicked                     (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_profilc_clicked                     (GtkWidget       *graphic,
                                        gpointer         user_data);

void
on_planc_clicked                       (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_dispc_clicked                       (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_editprofilc_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_validprofilec_clicked               (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_retourpc_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_editdispc_clicked                   (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_retourcdis_clicked                  (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_valdispc_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_retourdispc_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_editplanc_clicked                   (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_retourcplan_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_valplanc_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_retourplanc_clicked                 (GtkWidget       *graphic,
                                        gpointer         user_data);


void
on_retourcp_clicked                    (GtkWidget       *graphic,
                                        gpointer         user_data);

