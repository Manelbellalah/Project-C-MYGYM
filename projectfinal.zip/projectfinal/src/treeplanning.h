#include <gtk/gtk.h>
#include "fonctionm.h"

void afficherplanning(GtkWidget *treeview);
