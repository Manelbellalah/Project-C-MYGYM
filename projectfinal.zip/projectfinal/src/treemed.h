#include <gtk/gtk.h>
#include "fonctionm.h"

void affichermed(GtkWidget *treeview);
