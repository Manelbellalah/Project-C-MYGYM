#include <gtk/gtk.h>
#include "fonctionm.h"

void afficherdeal(GtkWidget *treeview);
