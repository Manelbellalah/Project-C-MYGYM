#include <gtk/gtk.h>
#include "fonctionm.h"

void afficherdiete(GtkWidget *treeview);
