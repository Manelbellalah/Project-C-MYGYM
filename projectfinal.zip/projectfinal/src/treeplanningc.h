#include <gtk/gtk.h>
void afficherplanningc(GtkWidget *treeview);
